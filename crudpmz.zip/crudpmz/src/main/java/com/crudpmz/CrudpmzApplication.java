package com.crudpmz;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrudpmzApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrudpmzApplication.class, args);
	}
}
